<?php $__env->startSection('content'); ?>
    <style>
        .card-body img {
            max-width: 100%;
            height: auto;
        }

        @media (min-width: 768px) {
            .card-body img {
                max-width: 300px;
                /* Adjust the maximum width for larger screens */
            }
        }
    </style>
    <h4 class="text-center">Listado Marcas</h4>

    <div class="row">
        <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-sm-12 mt-3 p-4" id="<?php echo e($marca->slug); ?>">
                <a href="<?php echo e(url('productos_por_marca', $marca->slug)); ?>">
                    <div class="card">
                        <div class="card-header">
                            <?php echo e($marca->nombre_marca); ?>

                        </div>
                        <div class="card-body">
                            <div class="row align-items-center">
                                <a href="<?php echo e(url('productos_por_marca', $marca->slug)); ?>">
                                    <img style="height: 100px; resize: contain"
                                        src="<?php echo e($marca->imagen ? asset('images/marcas/') . '/' . $marca->imagen : asset('images/sin_imagen.png/')); ?>"
                                        alt="" srcset="">

                            </div>
                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ihan\ihan\resources\views/marcas/index_marcas.blade.php ENDPATH**/ ?>