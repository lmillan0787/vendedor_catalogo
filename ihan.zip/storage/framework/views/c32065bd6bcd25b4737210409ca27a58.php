<div class="col-md-3 col-sm-12 mt-3 p-4">
    <div class="card">
        <div class="card-header fw-bold" id="div-descripcion-<?php echo e($producto->id); ?>">
            <?php echo e($producto->descripcion_producto); ?>

        </div>
        <div class="card-body">
            <div class="row align-items-center">
                <img class="producto-imagen"
                    src="<?php if($producto->imagen == null): ?> <?php echo e(asset('images/sin_imagen.png/')); ?> <?php else: ?> <?php echo e(asset('images/productos/') . '/' . strtolower($producto->nombre_marca) . '/' . $producto->imagen); ?> <?php endif; ?>"
                    alt="" srcset="">
            </div>
            <div class="row">
                <div class="col-md-6">Precio</div>
                <div class="col-md-6 fw-bold" id="div-precio-<?php echo e($producto->id); ?>"> <?php echo e($producto->precio); ?> </div>
            </div>
            <div class="row">
                <div class="col-md-6">IVA</div>
                <div class="col-md-6 fw-bold" id="div-iva-<?php echo e($producto->id); ?>"><?php echo e($producto->iva); ?></div>
            </div>
            <div class="row">
                <div class="col-md-6">Precio con Iva</div>
                <div class="col-md-6 fw-bold" id="div-precio-iva-<?php echo e($producto->id); ?>"><?php echo e($producto->precio_con_iva); ?></div>
            </div>
            <div class="row pb-2">
                <div class="col-md-6">Unidades</div>
                <div class="col-md-6">
                    <input type="text" name="unidades_pedido" id="unidades_pedido-<?php echo e($producto->id); ?>" class="form-control">
                </div>
            </div>
            <div class="card-footer" class="row p-2">
                <button type="button" class="btn btn-primary float-end" id="boton-pedido" onclick="agregarAlPedido(<?php echo e($producto->id); ?>)">Agregar al
                    Pedido</button>
            </div>
        </div>

    </div>
</div>
<?php /**PATH C:\laragon\www\ihan\ihan\resources\views/components/detalle-producto.blade.php ENDPATH**/ ?>