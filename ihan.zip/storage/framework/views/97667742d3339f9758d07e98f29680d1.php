<?php $__env->startSection('content'); ?>
    <div class="row">
        <h4 class="text-center">Listado Productos</h4>
    </div>
    <div class="row">
        <div class="col-md-6 mx-4">
            <?php if (isset($component)) { $__componentOriginalc649364f2f08b25174b08ac9d614a2d0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc649364f2f08b25174b08ac9d614a2d0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.seguimiento-pedido','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('seguimiento-pedido'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc649364f2f08b25174b08ac9d614a2d0)): ?>
<?php $attributes = $__attributesOriginalc649364f2f08b25174b08ac9d614a2d0; ?>
<?php unset($__attributesOriginalc649364f2f08b25174b08ac9d614a2d0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc649364f2f08b25174b08ac9d614a2d0)): ?>
<?php $component = $__componentOriginalc649364f2f08b25174b08ac9d614a2d0; ?>
<?php unset($__componentOriginalc649364f2f08b25174b08ac9d614a2d0); ?>
<?php endif; ?>
            <a href="<?php echo e(route('productos')); ?>#<?php echo e($id); ?>" class="btn btn-dark text-white">Volver</a>
        </div>
    </div>
    <div class="row mt-3 mx-4">
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if (isset($component)) { $__componentOriginal07f1c37ce69f33602e13066546979d4d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal07f1c37ce69f33602e13066546979d4d = $attributes; } ?>
<?php $component = App\View\Components\DetalleProducto::resolve(['producto' => $producto] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('detalle-producto'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\DetalleProducto::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal07f1c37ce69f33602e13066546979d4d)): ?>
<?php $attributes = $__attributesOriginal07f1c37ce69f33602e13066546979d4d; ?>
<?php unset($__attributesOriginal07f1c37ce69f33602e13066546979d4d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal07f1c37ce69f33602e13066546979d4d)): ?>
<?php $component = $__componentOriginal07f1c37ce69f33602e13066546979d4d; ?>
<?php unset($__componentOriginal07f1c37ce69f33602e13066546979d4d); ?>
<?php endif; ?>

   
   <?php if (isset($component)) { $__componentOriginal3e3a9f8ef07f175eda8c9e8266b1ac12 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e3a9f8ef07f175eda8c9e8266b1ac12 = $attributes; } ?>
<?php $component = App\View\Components\ModalSeguimientoPedido::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal-seguimiento-pedido'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ModalSeguimientoPedido::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e3a9f8ef07f175eda8c9e8266b1ac12)): ?>
<?php $attributes = $__attributesOriginal3e3a9f8ef07f175eda8c9e8266b1ac12; ?>
<?php unset($__attributesOriginal3e3a9f8ef07f175eda8c9e8266b1ac12); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e3a9f8ef07f175eda8c9e8266b1ac12)): ?>
<?php $component = $__componentOriginal3e3a9f8ef07f175eda8c9e8266b1ac12; ?>
<?php unset($__componentOriginal3e3a9f8ef07f175eda8c9e8266b1ac12); ?>
<?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->startSection('js'); ?>
    <script>
        const ruta_assets = "<?php echo e(asset('images')); ?>";
    </script>
    <script src="<?php echo e(asset('js/pages/index_productos.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ihan\ihan\resources\views/productos/detalles_producto.blade.php ENDPATH**/ ?>