<div class="col-md-4 col-sm-12 mt-3 p-4" id="<?php echo e($producto->id); ?>">
    <a href="<?php echo e(route('productos.detalles.producto', ['id' => $producto->id])); ?>">
        <div class="card">
            <div class="card-header fw-bold">
                <?php echo e($producto->descripcion_imagen); ?>

            </div>
            <div class="card-body">
                <div class="row align-items-center">
                    <a href="<?php echo e(route('productos.detalles.producto', ['id' => $producto->id])); ?>">
                        <img class="producto-imagen" src="<?php if($producto->imagen == null): ?> <?php echo e(asset('images/sin_imagen.png/')); ?> <?php else: ?> <?php echo e(asset('images/productos/') . '/' . $marca->nombre_marca . '/' . $producto->imagen); ?> <?php endif; ?>"
                            alt="" srcset="">
                    </a>
                </div>
            </div>
        </div>
    </a>
</div>
<?php /**PATH C:\laragon\www\ihan\ihan\resources\views/components/detalle-producto-categoria.blade.php ENDPATH**/ ?>