<?php

namespace App\Services;

class PedidoService {

    public function __construct()
    {
    }
}
